package ru.job4j.generics;

import java.util.Date;

public class Programmer extends Person {
    public Programmer(String name, int age, Date birthday) {
        super(name, age, birthday);
    }
}
